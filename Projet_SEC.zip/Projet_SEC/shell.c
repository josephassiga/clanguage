#define _GNU_SOURCE /*Pour utiliser get_current_dir_name()*/
#include "unistd.h" /*get_current_dir_name()*/
#include "errno.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "sys/wait.h"
#include "ctype.h"
#include "assert.h"
#include "string.h"

#define FIN_FILS   2
#define ERREUR_EXEC 127

void cd(char*pathname);
void prompt(void);
void waitChild(pid_t pid, int status);
char **recupererCommande (char *s, const char *ct);
int main(){
    

     pid_t pid; 
     char commande[256];
     int status = 0;
     char ** options = NULL;
     while(1)
     {	
     
        printf(">");
       fgets(commande,sizeof commande,stdin);
         /* J'enlève le retour à la ligne.*/
        if(strchr(commande,'\n')) *strchr(commande,'\n') = 0; 
        /* Je vide l'entrée standard. */
       fflush(stdin);
       pid = fork();
       assert(pid != -1);
       if(pid == 0)
       {
                 if(!strcmp(commande,"exit") || !strcmp(commande,"quit") || !strcmp(commande,"q")) 
                 {
                     exit(FIN_FILS);
                     /*kill(pid,9);*/
                     
                 }
                 else
                 {                   
                     options = recupererCommande(commande, " ");
                     execvp((const char*)options[0],options);
                     perror("Erreur de la fonction execvp");
                     exit(ERREUR_EXEC);
                 }
       }
       else
       {
          waitChild(pid,status);        
       } 
        
  }
     
     return EXIT_SUCCESS;

}

void waitChild(pid_t pid, int status){

  if(waitpid(pid, &status,0) > 0)
  {
      if(WIFEXITED(status)) 
      {
         if(WEXITSTATUS(status) == FIN_FILS)
         {
            /*Je tue le Père et je sort du Programme*/
             exit(EXIT_SUCCESS);
         }
         else
         {
            printf("Le Fils de PID: %d se termine par exit:  %d\n", pid,WEXITSTATUS(status));
         }
      }
      else if(WIFSIGNALED(status))
      {
           printf("Le Fils de PID: %d se termine par un signal %d\n", pid,WTERMSIG(status));
      }
      else if(WIFSTOPPED(status)) 
      { 
           printf("e Fils de PID: %d est stoppé par un signal %d\n",pid, WSTOPSIG(status));
      }
  }


}

char **recupererCommande (char *s, const char *ct){
   char **tab = NULL;

   if (s != NULL && ct != NULL)
   {
      int i;
      char *cs = NULL;
      size_t size = 1;
      for (i = 0; (cs = strtok (s, ct)); i++)
      {
         if (size <= i + 1)
         {
            void *tmp = NULL;
            size <<= 1;
            tmp = realloc (tab, sizeof (*tab) * size);
            if (tmp != NULL)
            {
               tab = tmp;
            }
            else
            {
               fprintf (stderr, "Memoire insuffisante\n");
               free (tab);
               tab = NULL;
               exit (EXIT_FAILURE);
            }
         }
         tab[i] = cs;
         s = NULL;
      }
      tab[i] = NULL;
 }
   return tab;
}

void cd(char*pathname){

  int  dir = 0;
  
 if((pathname == NULL) || (!strlen(pathname))){
     
             printf("%s@%s\n",getenv("USER"),getenv("HOSTNAME"));
  }
  else
  {
             dir = chdir(pathname);
             if(dir != -1) printf("%s\n",get_current_dir_name());
             else perror("Erreur ouverture:");
         
  }

}

void prompt(void){

  printf("%s ",get_current_dir_name());

}

