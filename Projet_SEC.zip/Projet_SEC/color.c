#include <stdio.h>

#define couleurnormale()  printf("\033[0m")
  
int main(void){
    printf("\033[01;31m");printf("Une jolie couleur\n");couleurnormale();
    printf("\033[01;32m");printf("Une jolie couleur\n");couleurnormale();
    printf("\033[01;33m");printf("Une jolie couleur\n");couleurnormale();
    printf("\033[01;34m");printf("Une jolie couleur\n");couleurnormale();
    printf("\033[01;35m");printf("Une jolie couleur\n");couleurnormale();
    printf("\033[01;38m");printf("Une jolie couleur\n");couleurnormale();
    return 0;
}	
