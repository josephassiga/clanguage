#include "pwd.h"
#include "time.h"
#include "stdio.h"
#include "fcntl.h"       /* open   */
#include "stdlib.h"
#include "dirent.h"      /* opendir */
#include "unistd.h"      /* read    */
#include "string.h"
#include "sys/stat.h"
#include "sys/types.h"   /* opendir */

#define CODE(M,m) ( \
  ( (M&0xfff) << 8)   |   ( (m&0xfff00) << 12)   |   (m&0xff)   \
)

#define NO_TTY_VALUE  CODE(0,0)


unsigned long mem(void);
const char *proc_time(unsigned long t);
void statProcessus(int pid,char*name);


typedef struct {
int  proc_pid;
int  proc_cpu;
int  proc_mem;
long proc_rss;
char proc_state;
int  proc_tty_num;
char proc_tty[10];
char proc_date[10];
char proc_name[50];
char proc_user[50];
unsigned long proc_vsz;
unsigned long proc_start;
unsigned long proc_time;
unsigned long proc_utime;
unsigned long proc_stime;

} processus;
processus proc;

unsigned long tailleMem;

int main(void){
        DIR *dir = NULL;
        struct dirent *ent;
        dir = opendir("/proc");
        tailleMem  = mem();
        printf("USER\tPID\t%%CPU\t%%MEM\tVSZ\tRSS\tTTY\tSTAT\tSTART\tTIME\tCOMMAND\n");
        while( (ent= readdir(dir)))
        {

         if(atoi(ent->d_name))
                statProcessus(atoi(ent->d_name),ent->d_name);
        }
        closedir(dir);


return 0;
}

const char *proc_time(unsigned long t){
  int hh,mm,ss;
  static char buf[32];
  int cnt = 0;
  t /= 100;
  ss = t%60;
  t /= 60;
  mm = t%60;
  t /= 60;
  hh = t%24;
  t /= 24;
  if(t) cnt = snprintf(buf, sizeof buf, "%d-", (int)t);
  snprintf(cnt + buf, sizeof(buf)-cnt, "%02d:%02d", mm, ss);
  return buf;
}


void statProcessus(int pid,char*name){
    char* tmp;
    char buf[800];
    int fd;
    int num;
    unsigned long cp;
    struct tm * timestart = NULL;
    struct stat st;
    struct passwd *p = NULL;
    snprintf(buf,32,"/proc/%d/stat",pid);
    if( (fd = open(buf,O_RDONLY,0)) == -1) exit(EXIT_FAILURE);
    num = read(fd, buf, sizeof buf -1);
    fstat(fd,&st);
    p = getpwuid(st.st_uid);
    close(fd);
    if(num < 80) exit(EXIT_FAILURE);
    buf[num] = '\0';
    tmp = strrchr(buf, ')');     
    *tmp = '\0';                 
    memset(proc.proc_name, 0, sizeof proc.proc_name);          
    sscanf(buf, "%d (%15c", &proc.proc_pid, proc.proc_name); 
    sscanf(tmp + 2,                    
       "%*c "
       "%*d %*d %*d %*d %*d "
       "%*d %*u %*u %*u %*u %lu %lu ",
       &proc.proc_utime,&proc.proc_stime);
       
       cp = (proc.proc_stime + proc.proc_utime);
       sleep(0.5);
       sscanf(tmp + 2,                    
       "%c "
       "%*d %*d %*d %d %*d "
       "%*d %*u %*u %*u %*u %lu %lu "
       "%*d %*d %*d %*d %*d %*d "
       "%lu %lu "
       "%ld ",
       &proc.proc_state,
       &proc.proc_tty_num,
       &proc.proc_utime,&proc.proc_stime,
       &proc.proc_start,&proc.proc_vsz, 
       &proc.proc_rss);
       
       proc.proc_rss*=(4096/1024);
       proc.proc_vsz/=1024;
       
       cp -= (proc.proc_stime +proc.proc_utime);
       timestart = localtime(&st.st_atime);
       
       sprintf(proc.proc_date,"%d:%01d",timestart->tm_hour,timestart->tm_min);
       
        memcpy(proc.proc_tty, "   ?   ", 8);
    if(proc.proc_tty_num != NO_TTY_VALUE) {
      int tty_maj = (proc.proc_tty_num>>8)&0xfff;
      int tty_min = (proc.proc_tty_num&0xff) | ((proc.proc_tty_num>>12)&0xfff00);
      if(tty_maj == 4)
      snprintf(proc.proc_tty, sizeof proc.proc_tty, "tty%-3d",tty_min);  
      else
      snprintf(proc.proc_tty, sizeof proc.proc_tty, "pts/%-3d",tty_min);  
    }
    sprintf(proc.proc_user,"%s",p->pw_name);
    
      printf( "%s\t%s\t%0.1lf\t"      
              "%0.1lf\t%lu\t%lu\t"     
              "%s\t%c\t%s\t"      
              "%s\t%s\n",
              proc.proc_user,name,(float)(cp/100),
              ((float)proc.proc_rss/(float)tailleMem)*100,proc.proc_vsz,proc.proc_rss,
              proc.proc_tty,proc.proc_state,proc.proc_date,
              proc_time(proc.proc_utime + proc.proc_stime),proc.proc_name);
             
}

unsigned long mem(void){
int fd;
char buf[28];
unsigned long memoireTotale;
snprintf(buf,32,"/proc/meminfo");
if( (fd = open(buf,O_RDONLY,0)) == -1) exit(EXIT_FAILURE);
        if (read(fd, buf, sizeof buf -1) != 27 ) exit(EXIT_FAILURE);
                                        sscanf(buf,"%*10s %lu",&memoireTotale);     
return memoireTotale;
close(fd);
}

