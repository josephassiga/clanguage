#include "stdio.h"
#include "stdlib.h"
#include "string.h"



int main(void){
  printf("%c",'-');
  printf("%c",'-');
  printf("%c",'-');
 return 0;
}


