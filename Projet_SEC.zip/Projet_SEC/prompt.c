#include "stdio.h"
#include "stdlib.h"
#include "sys/param.h"
#include "string.h"
#include "unistd.h"

int main ()
{
  char commande[256];
  char chemin_complet[MAXPATHLEN];
  char const *aux = get_current_dir_name();

         if (aux == NULL)
         {
            aux = "assigababoye";
         }

  printf("~%s $ ",aux);
  while(1)
  {
	fgets(commande,sizeof commande,stdin);

	if(strchr(commande,'\n')) 			*strchr(commande,'\n') = 0;
	if(realpath(commande, chemin_complet)==NULL)	perror("");
  	else 
	{

	      chdir(commande);
    	      fprintf(stderr, "~%s$ ",chemin_complet);
    	}
  }
return EXIT_SUCCESS;
}
