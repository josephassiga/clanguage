#define _GNU_SOURCE /*Pour utiliser get_current_dir_name()*/
#include "stdio.h"
#include "dirent.h"
#include "stdlib.h"
#include "unistd.h" /*get_current_dir_name()*/
#include "string.h"
#include "errno.h"


void cd(char*pathname);

int main(int argc, char* argv[]){
  cd(argv[1]);

return 0;
}

void cd(char*pathname){

  int  dir = 0;
  char* user;
  char* host;
  
 if((pathname == NULL) || (!strlen(pathname))){
     
            user = getenv("USER");
            if(user == NULL) user = " ";
            host = getenv("HOSTNAME");
            if(host == NULL) host = " ";
            printf("%s@%s\n",user,host);
  }
  else
  {
             dir = chdir(pathname);
             if(dir != -1) printf("%s\n",get_current_dir_name());
             else perror("Erreur ouverture:");
         
  }

}
