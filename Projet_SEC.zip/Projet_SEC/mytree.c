#define _GNU_SOURCE
#define _BSD_SOURCE
#include "pwd.h"
#include "sys/types.h" /*opendir()*/
#include "dirent.h"    /*opendir()*/
#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include "string.h"
#include "dirent.h"  /* readdir() */
#include "sys/types.h"
#include "sys/stat.h"
#include "errno.h"
#include "ctype.h"

#define couleurnormale()  printf("\033[0m")
#define TRUE    1
#define FALSE   0
/* Voire les fonctions FTW, fts.*/

void myls(char* fic);
void couleur(char* filename,int filetype);
int cmpString(const void *p1, const void *p2);


int main(int argc, char** argv){
 
  myls((char*)argv[1]);
  
  return 0;
  
}

void myls(char* fic){

struct stat sb;
struct dirent *st;
/*char* repParent;
char* repFils;*/
char *contenuRepertoire[256];
char *repertoire[256];
char home[256];
char *tmp;
char*s;
int cpt  = 0;
int cpt2 = 0;
int i = 0 ;
int j;
DIR* dir;



if(fic == NULL){
  sprintf(home,"%s",get_current_dir_name());
  
}
else{
 
    sprintf(home,"%s",fic);
}
  
 /* printf("home = %s\n",home);*/
  dir = opendir(home);
  
 /* Je sauvegarde le repertoire parent .
  repParent = home;*/
  
  if(dir == NULL) {
      perror("Erreur opendir():"); 
      exit(-1);
  }
  /*Je recupère le nom du repertoir courant*/
  tmp = strrchr(home,'/');
  couleur(tmp+1,TRUE);
  while((st = readdir(dir)))
  {
  
  	if (*st->d_name == '.')
  	{
  		if (*(st->d_name+1)=='\0') continue;	
  		if ((*(st->d_name+1)=='.')&&(*(st->d_name+2)=='\0'))continue; 
  	}
  	
       if(*st->d_name == '.')
  	{
  	        if ( isalnum(*(st->d_name+1))) continue;
  	}
  	
       if(stat(st->d_name, &sb) == -1)
        {
               perror("stat");
               exit(-1);
        }

      if(S_ISDIR(sb.st_mode))
       {
         
         s = (char*)malloc( sizeof(home) + sizeof(st->d_name) + 2);
         sprintf(s,"%s/%s",home,st->d_name);
         repertoire[cpt2++] = s;               
      }
      else
      {
        /*printf("%s\n", st->d_name);*/
        contenuRepertoire[cpt++] = st->d_name;
      }
 
  }
  
     if(cpt >= 1) /* Si j'ai au moins un fichier dans mon repertoire.*/
      {
        qsort(&contenuRepertoire[0],cpt,sizeof(*contenuRepertoire),cmpString);
        while(i < cpt)
        {  
            printf("-- %s\n",contenuRepertoire[i++]);
        }
      }
  
  
   for(j = 0;j < cpt2;j++) /* Si j'ai des repertoires dans mon repertoire courant. */
   {
       /* Je change de repertoire 
        repParent = home;
        repFils   = repertoire[j];*/
        chdir(repertoire[j]); 
        myls(repertoire[j]);
        /*Je reviens sur le repertoire parent.*/
        chdir("..");
    }
  closedir(dir);

}

void couleur(char* filename, int filetype){
 if(filetype == TRUE)/*Repertoire*/
   printf("\033[01;%dm",34);printf("%s\n",filename);couleurnormale();

}


int cmpString(const void *p1, const void *p2)
    {
           /* The actual arguments to this function are "pointers to
              pointers to char", but strcmp(3) arguments are "pointers
              to char", hence the following cast plus dereference */

           return strcmp(* (char * const *) p1, * (char * const *) p2);
   }

