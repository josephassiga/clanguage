#ifndef  FONCTION_H
#define  FONCTION_H

#define RED            31
#define GREEN          32
#define YELLOW         33
#define BLUE           34
#define WHITE          35
#define TRUE           1
#define FALSE          0
#define FIN_FILS       2
#define backGround     0
#define foreGround     1
#define ERREUR_EXEC    127
#define TAILLE_MEMOIRE 4096


#define CHECK(str,message) {\
                       if(str == -1){\
                       perror(message);\
                       exit(EXIT_FAILURE);}\
                      }


#define CODE(M,m) ( \
  ( (M&0xfff) << 8)   |   ( (m&0xfff00) << 12)   |   (m&0xff)   \
)

#define NO_TTY_VALUE  CODE(0,0)

#define couleur(param) fprintf(stderr,"\b \033[%sm",param)


typedef enum {CHEVRON_SIMPLE_DROIT,CHEVRON_SIMPLE_DROIT_K,CHEVRON_SIMPLE_DROIT_2,
              CHEVRON_DOUBLE_DROIT,CHEVRON_DOUBLE_DROIT_2,CHEVRON_DOUBLE_DROIT_K,
              CHEVRON_SIMPLE_GAUCHE} Chevron;
            
char * tableauChevron[7] ;  

typedef struct {
  int   pid;          /* numero du pid du processus.                                                     */
  int   type;         /* 0: background, 1: foreground.                                                   */
  int   numJob;       /* Numero du job, -1 si il s'agit d'un processus en foreground sinon numero du job.*/
  char* nomProc;      /* Nom du processus.                                                               */
  char* state;
}ElementTable;

typedef struct{
char* repChevron;
Chevron type;
}typeChevron;


typedef struct{
  int NMax;
  int N;
  ElementTable* Element;
}Processus;


typedef struct {
int  proc_pid;
int  proc_cpu;
int  proc_mem;
long proc_rss;
char proc_state;
int  proc_tty_num;
char proc_tty[10];
char proc_date[10];
char proc_name[50];
char proc_user[50];
unsigned long proc_vsz;
unsigned long proc_start;
unsigned long proc_time;
unsigned long proc_utime;
unsigned long proc_stime;

}processus;

typedef struct{

char nomVariable[100];
char valeurVariable[100];
char typeVariable;       /* L: Locale et E : Environnement.*/
}Var;


typedef struct{
Var* Element;
int  N;
}Variable;

Variable*     V                    ;
Processus*    P                    ; 
int           NBV                  ;
char**        opt                  ;
char*         dir                  ;
processus     proc                 ;
int           status               ;
char**        commande             ;
int           numeroJob            ;
unsigned long tailleMem            ;
int           alternative          ;
int           pointVirgule         ;
int           chevronDroit         ;
int           etCommerciale        ;
int           caracterePipe        ;
int           chevronGauche        ;
int           chevronDouble        ;
char*         ligneCommande        ;
int           metaCaractere        ;
int           caractereBackground  ;



void          _set();
void          init();								/*initialisation*/
void          myfg();								/*gestion du foreground*/
void          mybg();								/*gestion du background*/
void          myps();								/*gestion du myps*/
void          myls();								/*gestion du myls*/
void          _setenv();
unsigned long mem(void);
char*         prompt(void);							/*lancement du prompt*/
void          execPipe(int i);							/*exécution d'un pipe*/
void          _set_(char*ligne);
void          sortieShell(void);						/*gestion de la sortie du shell*/
char          *trim (char *str);
void          execRedirection();						/*gestion des redirections*/
void          _P(int identifiant);
void          _V(int identifiant);
int           isPipe(char* ligne);						/*reconaître un pipe*/
void          myjobs(Processus*P);						/*liste des jobs*/
Processus*    initTable(int NMax);
void          _myfg(char * numPid);						/*mettre en foreground le processus en param*/
void          _mybg(char * numPid);						/*mettre en background le processus en param*/
void          _setenv_(char*ligne);
void          sequenceAlternative();						/*gestion du sequencement*/
int           newSemaphore(int init);
void          freeSemaphore(int sem);
Variable*     initVariable(int size);
void          handler_ctrc(int signal);						/*gestion du ctrl C*/
void          arrierePlan(char *ligne);						/*lancement de processus en arrière plan*/
const char *  proc_time(unsigned long t);
int           isRedirection(char* ligne);					/*reconnaître une redirection*/
void          detruireTable(Processus*P);				   /*detruction d'un tableau d'un processus passé en paramétre*/
void          detruireTabVar(Variable* v);
void          gestionFils(int numSignale);					
glob_t        gestionWildCar(char* ligne);					/*gestion des wilcards*/
void          gestion_ctrz(int numsignale);					/*gestion du ctrl Z*/
void          waitChild(pid_t pid, int status);					/*message d'informations après l'attente de la mort dufils*/
void *        newMemoire(size_t size,int *shm);
void          statProcessus(int pid,char*name);					/*etat des processus*/
void          listdirR(char* dirname, int lvl);					/*parcours récursif*/
void          listdirAR(char* dirname, int lvl);				/*parcours récursif avec fichiers cachés*/
void          freeMemoire(void* valeur,int mem);
char*         colorer(int typeColor,char* texte);				/*coloration*/
int           isSequenceAlternative(char* ligne);				/*reconnaître une séquence alternative*/
ElementTable* recupererElement(Processus*P,int pid);				/*recherche d'un processus dans le tableau des processus*/
char          **recupererCommande (char *s, const char *ct);              /* fonction split : stocke dans un tableau la commande en param*/
void          affiche_statusL (struct stat status,char * nom);			/*myls*/
void          affiche_statusA (struct stat status,char * nom);			/*myls avec fichiers cachés*/
void          insererDsTable(Processus *P,ElementTable*new_element);		/*Ajout d'un processus dans la table des processus*/
ElementTable  creerElement(int p,int t,int numJob,char *str,char *state); /*creation d'un tableau contenant les propriétés d'un processus*/
void          affiche_statusR (struct stat status,char * nom,char * name);	/*affichage récursif*/
void          affiche_statusAR (struct stat status,char * nom,char * name);	/*affichage récursif avec fichiers cachés*/



#endif
